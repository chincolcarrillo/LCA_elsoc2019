# LCA_elsoc2019
Repositorio para reproducibilidad del estudio "Patrones Actitudinales ante la Protesta en Chile tras el Estallido Social de Octubre 2019" acorde al protocolo IPO

Para más información contactar a les investigadores:

* Carolina Carrillo Devia carolina.carrillo@ug.uchile.cl
* Enzo Zurita Elgueta
* Moira Martínez Sembler